create definer = root@localhost view v_dept_emp as
select `e`.`ENAME`    AS `ename`,
       `d`.`DNAME`    AS `dname`,
       `e`.`SAL`      AS `sal`,
       `e`.`HIREDATE` AS `hiredate`,
       `e`.`DEPTNO`   AS `deptno`
from `bjpowernode`.`emp` `e`
         join `bjpowernode`.`dept` `d`
where ((`e`.`DEPTNO` = `e`.`DEPTNO`) and (`e`.`DEPTNO` = 10));

